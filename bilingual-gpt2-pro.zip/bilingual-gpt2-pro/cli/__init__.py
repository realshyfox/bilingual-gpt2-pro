"""Command-line interface tools for bilingual GPT-2 training."""

from .setup_wizard import SetupWizard

__all__ = ['SetupWizard']
